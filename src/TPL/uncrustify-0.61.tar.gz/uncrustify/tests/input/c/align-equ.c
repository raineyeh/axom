
// note - set threshold to three
void foo(void)
{
   a = 1;
   bb = 2;
   ccc = 3;
   dddd = 4;
   eeeee = 5;
   ffffff = 6;



   a = 1;
   eeeeee = 5;
   fffffff = 6;



   a = 1;
   eeeee = 5;
   ccc = 3;
   ffffff = 6;


   a = 1;
   iiiiiiiiiiiiieeeee = 5;
   ccc = 3;
   ffffff = 6;
}

