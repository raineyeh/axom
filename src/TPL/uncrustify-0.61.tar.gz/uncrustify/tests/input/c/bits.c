struct foo {
  unsigned long bar;
  u_int ndots : 4,
nsort: 4,
: 0; 
};

