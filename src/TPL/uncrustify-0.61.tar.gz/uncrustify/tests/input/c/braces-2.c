while (a >= 0)
{
   if (b)
      for (j = 0; j < 10; j++)
      {
         if (j == b)
         {
            return;
         }
         a++;
      }
   b--;
}

