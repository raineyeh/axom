# define SOME_MACRO \
    bool has_err; \  
    bool is_comp;\  
    struct some_stream ostream

