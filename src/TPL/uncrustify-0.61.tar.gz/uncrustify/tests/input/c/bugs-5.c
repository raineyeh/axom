
static void log_roll_file(log_output_t *plo)
{
   INT32       retcode;
   const CHAR  *name_save;
   const CHAR  *name_temp;

   if (plo->pfile != NULL)
   {

   }
}

