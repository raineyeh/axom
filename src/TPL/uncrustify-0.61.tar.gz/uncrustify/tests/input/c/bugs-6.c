/*=-------------------------------------------------------------------------=*\
*
|  FUNCTION NAME: mult2
|
|  DESCRIPTION:
|     Multiplies a number by two.
|
|  INPUTS/OUTPUTS:
|     val - the number to double
|
|  RETURNS:
|     val * 2
*
\*=-------------------------------------------------------------------------=*/
int mult2(int val)
{
   return val * 2;
}

