int do_this
(
   int x,
   int y
)
{
   x += y;              // x = x + y
   if(x == 3)
      x++;      // x plus 1

   return (x)
}
