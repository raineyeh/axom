int a; //a
int a; ///a
int a; ///<a
int a; //!a
int a; //!<a
