
void FSUB(MPI_Foo)(MPI_Fint* sendcount); 

