
static int another_try;
struct something yup;
align_me_t  please;
const char *name = "hello";
static nothing really;

