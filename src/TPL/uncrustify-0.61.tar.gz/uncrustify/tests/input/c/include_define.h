#define MY_HEADER  <foo/inc.h>

#include MY_HEADER


