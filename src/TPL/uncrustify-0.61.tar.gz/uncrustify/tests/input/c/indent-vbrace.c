
void x(void)
{
if (a>b)
b=a;
}
