void foo()
{
   if (c * ssize < initialCapacity);
   if (Item* item=nextItem());
}
